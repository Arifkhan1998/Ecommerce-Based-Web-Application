<!DOCTYPE html>
<html>
<head>
      <meta name="viewport" content="with=device-width, intitial-Scale=0.1">
	  <title> E-Commerce Based Web Application</title>
	  <link rel="stylesheet" href="style1.css">
	 </head>
	 <body>
	  <section class="header">
	  <nav>
	  <div >
	  <ul>  
	  <li><a href="login.php">Admin</a></li>
	  <li><a href="about.php">About</a></li>
	  <li><a href="contact.php">Contact</a></li>
	  <li><a href="customer_login.php">Login</a></li>
	  <li><a href="guest_user_signup.php">Sign in</a></li>
	  <li><a href=" ">Home</a></li>
	  
	  
	  
	 
	     </ul>
	  </div>
	  </nav>
	  <div class="text-box">
	  <h1> Virtual Shoppers huB</h1>
	  <p> "A classic never goes out of style" <br>
	  "The possibilities are endless" </p>
	  
	  <a href="guest_login.php" class="visit-btn">Visit Page </a> 
	  <!--<a href="index2.php" class="visit-btn">Visit page </a>-->
	  <a href="customer_login.php" class="shop-btn">Shop Now </a> 
	  </div>
	   
	  
	  
	  
	 
	 </body>
	 </html>