<html>
    <head>
        <style>
            body {
  background-color: lavender;
}
        </style>
        <body>
                <h2 align="center">Who we are!</h2>
                <p>Visual Shopper's huB is an eminent lifestyle brand in the retail fashion industry of Bangladesh with the purpose of Sailing life. As a fashion brand, Sailor is renowned for its unique style and variety of collections. We crafted our fashionable attires & accessories for all age ranges who believe themselves to be stand out with their unique fashion sense and style statement.

                Visual Shopper's huB celebrates all festivals and seasons with an extraordinary collection of products that are designed in-house as we have one of the largest design teams to deliver a fabulous new fashion every season.
In this journey of fashion, we always want to make a quality effort to provide better products and services to our customers.

 

Thank you for choosing to shop with us!</p>
               <h5 align="center"><i>Keep yourself updated with the latest Visual Shopper's huB News, Fashion Updates and Blogs! Subscribe here! It’s simple</i></h5>
               <h6 align="right">Need Help : +8801777702000</h6>
        </body>
    </head>
</html>