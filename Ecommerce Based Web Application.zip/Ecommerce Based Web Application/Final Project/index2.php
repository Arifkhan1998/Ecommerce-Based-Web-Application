<!--DOCTYPE html-->
<html>
<head>
      <meta name="viewport" content="with=device-width, intitial-Scale=0.1">
	  <title> E-Commerce Based Web Application</title>
	  <link rel="stylesheet" href="style2.css">
	 </head>
	 <body>
	  <section class="header">
	  <nav>
	  <div >
	  <ul>  
      <li><a href="index.php">Log Out</a></li>
	  <li><a href=" ">About</a></li>
	  <li><a href=" ">Contact</a></li>
	  <li><a href="allcategories.php">All Categories</a></li>
	  <li><a href="allproducts.php">All Products</a></li>
	  <li><a href="index.php">Home</a></li>
	  </ul>
      </div>
      </nav>
	 
	  </section> 
	 
	 </body>
	 </html>