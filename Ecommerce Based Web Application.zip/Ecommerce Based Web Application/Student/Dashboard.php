<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Dashboard</title>
</head>
<body>
      <h1 align="center">Dashboard</h1><br>
      
      <div align="center">
      	    <a href="AllStudents.php">All Student Information</a>&nbsp;&nbsp;
            <a href="AddStudent.php">Add Student</a>
      </div>
      
</body>
</html>