<html>

	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="styles/mystyle.css">
	</head>
	<body>
		<h3 align= "right"><a href="index.php">Logout</a></h3>	
		<h4 align= "center"><a href="dashboard.php">Dashboard</a></h4>
		<h4 align= "center"><a href="allproducts.php">All Products</a></h4>
		<h4 align= "center"><a href="addproduct.php">Add Product</a></h4>
		<h4 align= "center"><a href="allcategories.php">All Categories</a></h4>
		<h4 align= "center"><a href="addcategory.php">Add Category</a></h4>
			